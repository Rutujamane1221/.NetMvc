﻿using System;
using System.Collections.Generic;

namespace FlightManagementSystem.Models;

public partial class UserDetail
{
    public int UserId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public string EmailId { get; set; } = null!;

    public string MobileNumber { get; set; } = null!;

    public string? SetPassword { get; set; }

    public string ConfirmPassword { get; set; } = null!;
}
