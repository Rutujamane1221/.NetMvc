using System;
using FlightManagementSystem.Models;

namespace FlightManagementSystem.Models
{
    public class FlightSearchViewModel
    {
        public string? Source { get; set; }
        public string? Destination { get; set; }
        public DateTime Date { get; set; }
        public List<FlightDetail>? Flights { get; set; }
    }
}
 
 