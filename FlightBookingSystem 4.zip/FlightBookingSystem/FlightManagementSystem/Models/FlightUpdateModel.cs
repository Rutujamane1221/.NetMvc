namespace FlightManagementSystem.Models;
public class FlightUpdateModel
{
    public required string? FlightId{get;set;}
    public decimal Fare{get;set;}

    public DateTime Date{get;set;}
}