namespace FlightManagementSystem.Models;
    public class UserLoginModel
    {
        public string? MobileNumber { get; set; }
        public string? Password { get; set; }
    }

