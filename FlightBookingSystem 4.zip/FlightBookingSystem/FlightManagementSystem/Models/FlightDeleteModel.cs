namespace FlightManagementSystem.Models;
public class FlightDeleteModel{
    public string?  FlightId{get;set;}
}