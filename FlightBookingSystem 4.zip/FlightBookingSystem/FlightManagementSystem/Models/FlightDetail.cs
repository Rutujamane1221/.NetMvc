﻿using System;
using System.Collections.Generic;

namespace FlightManagementSystem.Models;

public partial class FlightDetail
{
    public string FlightId { get; set; } = null!;

    public string Source { get; set; } = null!;

    public string Destination { get; set; } = null!;

    public DateTime Date { get; set; }

    public decimal Fare { get; set; }
}
