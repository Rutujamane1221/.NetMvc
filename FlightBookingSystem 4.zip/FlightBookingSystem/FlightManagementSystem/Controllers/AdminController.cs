using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using FlightManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;


namespace AdminController.Controllers;

public class AdminController : Controller
{
    private readonly FlightBookingSystemContext context;

        public AdminController(FlightBookingSystemContext _context)
        {
            context = _context;
        }
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult HomePage(string role)
    {
        if (role == "Admin")
        { 
            return RedirectToAction("AdminLogin");
            
        }
        else if (role == "User")
        {
            return RedirectToAction("UserRegistration","User");
            
        }
        
         return RedirectToAction("Index"); // Redirect back to same page
    }
    public IActionResult AdminLogin()
    {
        return View();
    }

    [HttpPost]
    public IActionResult AdminLogin(AdminLoginModel model)
    {
        if(ModelState.IsValid)
        {
            if(model.Username=="Admin" || model.Username=="admin" && model.Password=="Pass@123")
            {
                HttpContext.Session.SetString("Username",model.Username);
                return RedirectToAction("AdminDashboard");
            }
            else
            {
                ModelState.AddModelError("Username","Invalid credentials.");
                //ViewBag.ErrorMessage = "Invalid credentials.";
            }
        }
        return View(model);    
    }

    public IActionResult AdminDashboard()
    {
        var flights=context.FlightDetails.ToList();
        return View(flights);
    }
    
    public IActionResult AddFlight()
    {
        var flightDetail = new FlightDetail
        {
            FlightId = GenerateFlightId() // Generate FlightId here
        };
        return View(flightDetail);
    }


    [HttpPost]
    public IActionResult Create(FlightDetail flightmodel)
    {
        if (ModelState.IsValid)
        {
                // Custom Validation
                if (flightmodel.Date < DateTime.Now)
                {
                    ModelState.AddModelError("Date", "Invalid Date");
                    
                }
                
                if (ModelState.IsValid)
                {
                    context.FlightDetails.Add(flightmodel);
                    context.SaveChanges();
                    ViewBag.SuccessMessage = "Flight added successfully!";
                    return View("AddFlight",new FlightDetail());
                }
        }   
        return View("AddFlight",flightmodel); 
        
    }
 
    public string GenerateFlightId()
    {
        Random random = new Random();
        int randomNumber = random.Next(1,1000); 
        string newId = "FN" + randomNumber.ToString("D3");

        // int count = context.FlightDetails.Count() + 1;
        // string newId = "FN" + count.ToString("D3");
        return newId;
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
            var flight = context.FlightDetails.Find(id);
            if (flight != null)
            {
                context.FlightDetails.Remove(flight);
                context.SaveChanges();
            }
            return RedirectToAction("AdminDashboard");
    }

    public IActionResult Update(string? id)
    {
        if (id == null)
        {
            return View("Admindashboard");
        }
   
        var flight = context.FlightDetails.Find(id);
        if (flight == null)
        {
            return View("Admindashboard");
        }

        var updateModel = new FlightUpdateModel
        {
        FlightId = flight.FlightId,
        Fare = flight.Fare,
        Date = flight.Date
        };
 
        return View(updateModel); // Return the flight object for the update view
    }

    [HttpPost]
    public IActionResult Update(FlightUpdateModel update)
    {
        if (ModelState.IsValid)
        {
            var flight = context.FlightDetails.Find(update.FlightId);
            if (flight != null)
            {
                // Custom Validation
                if (update.Fare <= 0)
                {
                    ModelState.AddModelError(nameof(update.Fare), "Fare must be a positive number.");
                }
    
                if (update.Date < DateTime.Now)
                {
                    ModelState.AddModelError(nameof(update.Date), "The date cannot be in the past.");
                }
    
                if (ModelState.IsValid) // Proceed only if all custom validations pass
                {
                    flight.Fare = update.Fare;
                    flight.Date = update.Date;
    
                    try
                    {
                        context.SaveChanges();
                        return RedirectToAction("Admindashboard"); // Redirect back to the flight list after updating
                    }
                    catch (DbUpdateException ex)
                    {
                        // Log the exception or handle specific DbUpdateException issues
                        ModelState.AddModelError("", "An error occurred while saving changes. Please try again.");
                    }
                }
            }
            else
            {
                ModelState.AddModelError("", "Flight not found.");
            }
        }
    
        // If ModelState is invalid, or an exception occurs, return the user to the update view with the model data.
        return View(update);
    }
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return View("AdminLogin");//Admin Logout
    }

 
}
