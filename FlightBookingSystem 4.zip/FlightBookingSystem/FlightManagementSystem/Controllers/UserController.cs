using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using FlightManagementSystem.Models;
using BCrypt.Net; 

namespace UserController.Controllers;
public class UserController:Controller
{
    private readonly ILogger<UserController> _logger;
    private readonly FlightBookingSystemContext context;

        public UserController(FlightBookingSystemContext _context)
        {
            context = _context;
        }

    public IActionResult UserRegistration()
    {
        return View();
    }
 // Add this at the top of your controller file

[HttpPost]
public IActionResult UserRegistration(UserDetail user)
{
    if (ModelState.IsValid)
    {
        // Ensure that the password and confirm password match
        if (user.SetPassword != user.ConfirmPassword)
        {
            ModelState.AddModelError("ConfirmPassword", "Passwords do not match.");
            return View();
        }

        // Check if the mobile number already exists in the database
        var existingUser = context.UserDetails.FirstOrDefault(u => u.MobileNumber == user.MobileNumber);
        if (existingUser != null)
        {
            ModelState.AddModelError("MobileNumber", "A user with this mobile number already exists.");
            return View();
        }

        // Hash the user's password before storing it
          string hashedPassword = BCrypt.Net.BCrypt.HashPassword(user.SetPassword);

            // Update the user object with the hashed password
            user.SetPassword = hashedPassword;
        
        context.UserDetails.Add(user);
        context.SaveChanges();

        // Optionally, log the user in after registration
        HttpContext.Session.SetString("MobileNumber", user.MobileNumber);
        return View("UserLogin");
    }

    return View();
}


    // [HttpPost]
    // public IActionResult UserRegistration(UserDetail user)
    // {
    //     if(ModelState.IsValid)
    //     {
    //          var existingUser = context.UserDetails
    //         .FirstOrDefault(u => u.MobileNumber == user.MobileNumber);

    //         if (existingUser != null)
    //         {
    //             ModelState.AddModelError("MobileNumber", "You have already registered with this mobile number.");
    //             //ViewBag.ErrorMessage="You have already registered with this mobile number.";
    //             return View("UserRegistration", user);
    //         }
    //         context.UserDetails.Add(user);
    //         context.SaveChanges();
    //         return RedirectToAction("UserLogin");
    //     }
    //     return View("UserRegistration",user);
    // }
    public IActionResult UserLogin()
    {
        return View();
    }

    // [HttpPost]
    // public IActionResult UserLogin(UserLoginModel userLogin)
    // {
    //     if(ModelState.IsValid)
    //     {   
    //         var user = context.UserDetails.FirstOrDefault(u => u.MobileNumber == userLogin.MobileNumber);
    //         if (user != null && user.SetPassword == userLogin.Password)
    //         {
    //                 HttpContext.Session.SetString("MobileNumber",userLogin.MobileNumber);
    //                 return View("UserDashboard");
    //         }
    //         else
    //         {
    //                 ModelState.AddModelError("Password", "Invalid username or password.");
    //                 //ViewBag.password = "Invalid credentials.";
    //                 return View(userLogin);
                    
    //         }
    //     }
    //     return View(userLogin);
    // }

[HttpPost]
public IActionResult UserLogin(UserLoginModel userLogin)
{
    if (ModelState.IsValid)
    {
        // Find the user by their mobile number
        var user = context.UserDetails
            .FirstOrDefault(u => u.MobileNumber == userLogin.MobileNumber);

        // If user doesn't exist or the passwords don't match
        if (user == null || userLogin.Password==null|| !BCrypt.Net.BCrypt.Verify(userLogin.Password, user.SetPassword))
        {
            // Invalid credentials, show error message
            //ViewBag.ErrorMessage = "Invalid username or password.";
            ModelState.AddModelError("Password","Invalid credentials");
            return View(userLogin);
        }

        // If credentials are correct, set session and redirect to dashboard
        HttpContext.Session.SetString("MobileNumber", user.MobileNumber);
        return RedirectToAction("UserDashboard");
    }

    return View(userLogin);
}
    public IActionResult UserOperation(string role)
    {
        if(HttpContext.Session.GetString("MobileNumber")!=null)
        {
            if(role=="SearchFlight")
            {
                return RedirectToAction("SearchFlight");
            }
            else if(role=="Logout")
            {
                return RedirectToAction("Logout");
            }
        }
        
        return View("UserLogin");
       // return View("UserDashboard");    
    }
    public IActionResult UserDashboard()
    {
        return View();
    }
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("UserLogin");
    }
    public IActionResult SearchFlight()
    {
        return View(new FlightSearchViewModel());
    }
    [HttpPost]
    public IActionResult Search(FlightSearchViewModel model)
    {
        try
        {
            if (ModelState.IsValid)
            {
                var flights = context.FlightDetails
                    .Where(f => f.Source == model.Source &&
                                f.Destination == model.Destination &&
                                f.Date.Date == model.Date.Date) // Compare only the date part
                    .ToList();
 
                model.Flights = flights;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while searching for flights.");
            ModelState.AddModelError("", "An error occurred while processing your request.");
        }
        return View("SearchFlight", model);
    }
}

